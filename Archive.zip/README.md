run tests first draft readme later
